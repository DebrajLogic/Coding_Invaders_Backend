videoTuple = ('Tuple in Python', [13.0, 134.5, 89.3, 98.4])

my_dict = dict()

my_dict[videoTuple[0]] = videoTuple[1]

print(my_dict)
